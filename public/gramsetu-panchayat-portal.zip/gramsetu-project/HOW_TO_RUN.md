# GramSetu — Digital Gram Panchayat Redressal System

## 🚀 Option 1: 1-Click Launch (Easiest)
- **Windows:** Double-click `run-windows.bat`
- **Mac / Linux:** Run `chmod +x run-mac-linux.sh && ./run-mac-linux.sh`

This automatically installs packages (if not installed) and opens http://localhost:3000 in your browser!

---

## 💻 Option 2: Standard Terminal Run
1. Open Terminal / Command Prompt in this folder:
   ```bash
   cd gramsetu-project
   npm install
   npm start
   ```
   *(or `npm run dev` for development mode)*

2. Open in your browser:
   - **Main Website (Citizen Portal):** http://localhost:3000
   - **Citizen Direct:** http://localhost:3000/citizen/index.html
   - **Admin Portal:** http://localhost:3000/admin/index.html
   - **API Health:** http://localhost:3000/api/health

---

## 🌐 Option 3: Deploy to Vercel / Netlify / Render

### Full-Stack (Render / Railway / Cloud Run / VPS):
1. Build: `npm run build`
2. Start: `npm start` (runs `node server.js` on port `$PORT`)
3. Add your `MONGODB_URI` environment variable if using MongoDB Atlas.

### Static Frontend (Vercel / Netlify):
- **Build command:** `npm run build`
- **Publish directory:** `dist`
- Pre-configured `vercel.json` and `netlify.toml` are included!
- To connect to your external backend, set `window.GRAMSETU_API_URL = "https://your-api.com"` or use the proxy in `vercel.json`.

---

## 🔑 Key Credentials & Configuration:
- **Master Admin Passcode:** GramSetu@2026
- **Database:** Works out-of-the-box with persistent built-in engine. To connect your cloud MongoDB Atlas, copy `.env.example` to `.env` and fill in `MONGODB_URI`.
